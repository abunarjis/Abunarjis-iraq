package com.example.sawwaqi.ui

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.example.sawwaqi.R

class FloatingWindowService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private lateinit var transcribedTextView: TextView
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val layoutParams = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )
        } else {
            WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )
        }

        layoutParams.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL

        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_window, null)
        transcribedTextView = floatingView.findViewById(R.id.tv_transcribed_text)

        // Initially hide the view
        floatingView.visibility = View.GONE
        windowManager.addView(floatingView, layoutParams)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.getStringExtra("action")) {
            "show" -> {
                floatingView.visibility = View.VISIBLE
                transcribedTextView.text = "بانتظار أمرك..."
                handler.removeCallbacks(hideRunnable)
            }
            "hide" -> {
                handler.postDelayed(hideRunnable, 2000) // Hide after 2 seconds
            }
            "update_text" -> {
                val text = intent.getStringExtra("text")
                transcribedTextView.text = text
            }
        }
        return START_STICKY
    }

    private val hideRunnable = Runnable { floatingView.visibility = View.GONE }

    override fun onDestroy() {
        super.onDestroy()
        if (::floatingView.isInitialized) {
            windowManager.removeView(floatingView)
        }
        handler.removeCallbacks(hideRunnable)
    }
}
