package com.example.sawwaqi

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.sawwaqi.service.VoiceAssistantService

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // This activity is primarily for settings, not a visible UI.
        // It's launched via a secret code.

        // Start the background service if it's not already running
        val serviceIntent = Intent(this, VoiceAssistantService::class.java)
        startService(serviceIntent)

        Toast.makeText(this, "Sawwaqi Settings (Hidden)", Toast.LENGTH_SHORT).show()

        // You can add UI elements for settings here if needed, or launch a fragment.
        // For now, it just starts the service and shows a toast.
        finish() // Close the activity immediately after starting the service/showing toast
    }
}
