package com.example.sawwaqi.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.sawwaqi.R
import com.example.sawwaqi.audio.WakeWordDetector
import com.example.sawwaqi.nlu.NLUProcessor
import com.example.sawwaqi.car.CarCommandExecutor
import com.example.sawwaqi.ui.FloatingWindowService
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.vosk.android.RecognitionListener
import java.io.IOException

/**
 * VoiceAssistantService: Permanent background service for BYD car voice control.
 * Handles wake word detection and command execution in Iraqi dialect.
 */
class VoiceAssistantService : Service(), RecognitionListener {

    private val TAG = "VoiceAssistantService"
    private var speechService: SpeechService? = null
    private var voskModel: Model? = null
    private lateinit var wakeWordDetector: WakeWordDetector
    private lateinit var nluProcessor: NLUProcessor
    private lateinit var carCommandExecutor: CarCommandExecutor

    override fun onCreate() {
        super.onCreate()
        startForegroundService()
        wakeWordDetector = WakeWordDetector(this)
        nluProcessor = NLUProcessor(this) // Initialize NLU Processor
        carCommandExecutor = CarCommandExecutor(this) // Initialize Car Command Executor
        initVoskRecognizer() // Initialize Vosk for speech recognition
        startWakeWordDetection()
    }

    private fun startForegroundService() {
        val channelId = "sawwaqi_service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Sawwaqi Assistant", NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("سواقي يعمل في الخلفية")
            .setContentText("بانتظار الأوامر الصوتية...")
            .setSmallIcon(R.drawable.ic_voice_assistant) // Ensure this drawable exists
            .build()

        startForeground(1, notification)
    }

    private fun initVoskRecognizer() {
        // Load Vosk model from assets (Arabic model)
        // Note: Model should be placed in assets/model-ar
        // You need to download an Arabic Vosk model and place it in app/src/main/assets/model-ar
        try {
            voskModel = Model(this, "model-ar") // Assuming 'model-ar' is the folder name in assets
            val recognizer = Recognizer(voskModel, 16000.0f)
            speechService = SpeechService(recognizer, 16000.0f)
            // Vosk will be started on wake word detection
        } catch (e: IOException) {
            Log.e(TAG, "Error initializing Vosk model: ", e)
        } catch (e: Exception) {
            Log.e(TAG, "Unknown error initializing Vosk: ", e)
        }
    }

    private fun startWakeWordDetection() {
        wakeWordDetector.startListening { wakeWordDetected ->
            if (wakeWordDetected) {
                Log.d(TAG, "Wake word detected. Starting speech recognition.")
                startSpeechRecognition()
                // Show floating UI
                val intent = Intent(this, FloatingWindowService::class.java)
                intent.putExtra("action", "show")
                startService(intent)
            }
        }
    }

    private fun startSpeechRecognition() {
        speechService?.startListening(this)
    }

    override fun onResult(hypothesis: String) {
        Log.d(TAG, "Vosk Result: $hypothesis")
        processVoiceCommand(hypothesis)
        // Hide floating UI after processing
        val intent = Intent(this, FloatingWindowService::class.java)
        intent.putExtra("action", "hide")
        startService(intent)
    }

    override fun onPartialResult(hypothesis: String) {
        Log.d(TAG, "Vosk Partial Result: $hypothesis")
        // Update floating UI with partial text
        val intent = Intent(this, FloatingWindowService::class.java)
        intent.putExtra("action", "update_text")
        intent.putExtra("text", hypothesis)
        startService(intent)
    }

    override fun onFinalResult(hypothesis: String) {
        Log.d(TAG, "Vosk Final Result: $hypothesis")
        // Final result after silence, process it if not already done by onResult
        // In Vosk, onResult usually provides the final result, onFinalResult might be redundant or for specific scenarios.
    }

    override fun onError(exception: Exception) {
        Log.e(TAG, "Vosk Error: ", exception)
        // Hide floating UI on error
        val intent = Intent(this, FloatingWindowService::class.java)
        intent.putExtra("action", "hide")
        startService(intent)
    }

    override fun onTimeout() {
        Log.d(TAG, "Vosk Timeout.")
        // Hide floating UI on timeout
        val intent = Intent(this, FloatingWindowService::class.java)
        intent.putExtra("action", "hide")
        startService(intent)
    }

    private fun processVoiceCommand(text: String) {
        val intent = nluProcessor.extractIntent(text)
        carCommandExecutor.execute(intent)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        speechService?.stop()
        speechService?.shutdown()
        wakeWordDetector.stopListening()
        voskModel?.close()
        Log.d(TAG, "VoiceAssistantService destroyed.")
    }
}
