package com.example.sawwaqi.car

import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.sawwaqi.nlu.CarCommandIntent

/**
 * CarCommandExecutor: Executes commands on the BYD car based on recognized intents.
 * This class would interface with BYD's DiLink system APIs or directly with CAN bus via a middleware.
 */
class CarCommandExecutor(private val context: Context) {

    private val TAG = "CarCommandExecutor"

    fun execute(commandIntent: CarCommandIntent) {
        Log.d(TAG, "Executing command: ${commandIntent.intentName} with entities: ${commandIntent.entities}")

        when (commandIntent.intentName) {
            "WINDOW_CONTROL" -> {
                val action = commandIntent.entities["action"]
                val target = commandIntent.entities["target"]
                Log.i(TAG, "Window Control: Action=$action, Target=$target")
                // Implement actual CAN bus or DiLink API call for window control
                sendDiLinkBroadcast("WINDOW_CONTROL", action, target)
            }
            "AC_CONTROL" -> {
                val action = commandIntent.entities["action"]
                Log.i(TAG, "AC Control: Action=$action")
                // Implement actual CAN bus or DiLink API call for AC control
                sendDiLinkBroadcast("AC_CONTROL", action)
            }
            "MEDIA_CONTROL" -> {
                val action = commandIntent.entities["action"]
                Log.i(TAG, "Media Control: Action=$action")
                // Implement actual DiLink API call for media control
                sendDiLinkBroadcast("MEDIA_CONTROL", action)
            }
            "UNKNOWN" -> {
                Log.w(TAG, "Unknown command received: ${commandIntent.entities}")
                // Optionally provide feedback to the user
            }
        }
    }

    private fun sendDiLinkBroadcast(commandType: String, vararg params: String?) {
        val intent = Intent("com.byd.action.CAR_CONTROL")
        intent.putExtra("command_type", commandType)
        params.forEachIndexed { index, param ->
            intent.putExtra("param_$index", param)
        }
        context.sendBroadcast(intent)
        Log.d(TAG, "Sent broadcast to DiLink: $commandType with params: ${params.joinToString()}")
    }
}
