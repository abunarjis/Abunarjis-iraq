package com.example.sawwaqi.nlu

import android.content.Context
import android.util.Log

/**
 * NLUProcessor: Handles Natural Language Understanding (NLU) for Iraqi dialect.
 * In a real application, this would integrate with a Rasa-trained model or a custom NLU engine.
 */
class NLUProcessor(private val context: Context) {

    private val TAG = "NLUProcessor"

    // Placeholder for intent and entity extraction
    fun extractIntent(text: String): CarCommandIntent {
        val lowerCaseText = text.lowercase()
        Log.d(TAG, "Processing NLU for: $lowerCaseText")

        return when {
            lowerCaseText.contains("افتح الجامة") || lowerCaseText.contains("نزل الشباك") -> {
                CarCommandIntent("WINDOW_CONTROL", mapOf("action" to "open", "target" to "all"))
            }
            lowerCaseText.contains("سد الجامة") || lowerCaseText.contains("صعد الشباك") -> {
                CarCommandIntent("WINDOW_CONTROL", mapOf("action" to "close", "target" to "all"))
            }
            lowerCaseText.contains("شغل المكيف") || lowerCaseText.contains("تبريد") -> {
                CarCommandIntent("AC_CONTROL", mapOf("action" to "on"))
            }
            lowerCaseText.contains("طفي المكيف") -> {
                CarCommandIntent("AC_CONTROL", mapOf("action" to "off"))
            }
            lowerCaseText.contains("علي الصوت") -> {
                CarCommandIntent("MEDIA_CONTROL", mapOf("action" to "volume_up"))
            }
            lowerCaseText.contains("نصي الصوت") -> {
                CarCommandIntent("MEDIA_CONTROL", mapOf("action" to "volume_down"))
            }
            else -> {
                CarCommandIntent("UNKNOWN", emptyMap())
            }
        }
    }
}

data class CarCommandIntent(
    val intentName: String,
    val entities: Map<String, String>
)
